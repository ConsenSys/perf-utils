git clone https://github.com/shazow/ethspam.git
cd ethspam/
make all
