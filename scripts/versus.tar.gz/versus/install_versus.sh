git clone https://github.com/INFURA/versus.git
cd versus/
make all
